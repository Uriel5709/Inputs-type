<header class="bd-header bg-dark py-3 d-flex align-items-stretch border-bottom border-dark">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <h1 class="d-flex align-items-center fs-4 text-white mb-0">
            <img src="../img/logo_m.jpg" width="38" height="30" class="me-3" alt="Bootstrap" />
            MercadoWeb.com
        </h1>
        <nav class="nav nav-masthead justify-content-center flex-grow-1">
            <a class="nav-link text-white" href="_productos.php">Más productos</a>
            <a class="nav-link text-white" href="_aliados_c.php">Aliados colaboradores</a>
            <a class="nav-link text-white" href="_soporte_d.php">Soporte de desarrollo</a>
        </nav>
        <a href="index.php" class="ms-auto link-light">MercadoWeb.com</a>
    </div>
</header>