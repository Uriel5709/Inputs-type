<!-- FOOTER -->
<footer class="container">
    <p class="float-end"><a href="#">Volver al inicio</a></p>
    <p>&copy; 2020–2024 Seguros Company, Inc. &middot; <a href="#">Privacidad</a> &middot; <a href="#">Terminos y condiciones</a></p>
</footer>

<?php
require_once "./_body_end.php";
?>