<?php
require_once "./_header.php";
?>

<div id="myCarousel" class="carousel slide mb-6" data-bs-ride="carousel">
	<div class="carousel-indicators">
		<button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
		<button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
		<button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
	</div>
	<div class="carousel-inner" style="background-image: url(../img/registro.jpg); background-repeat: no-repeat; background-size: cover; background-position: center">
		<div class="carousel-item active">
			<svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
				<rect width="100%" height="100%" fill="var(--bs-secondary-color)" />
			</svg>
			<div class="container">
				<div class="carousel-caption text-start">
					<h1>Empieza desde ya!</h1>
					<p class="opacity-75">Registra tu mascota en nuestro hospital, y dale un seguro de vida a tu amigo fiel.</p>
					<p><a class="btn btn-lg btn-primary" href="#form">Registrar aquí</a></p>
				</div>
			</div>
		</div>
		<div class="carousel-item" style="background-image: url(../img/cuidamosmascota.jpg); background-repeat: no-repeat; background-size: cover; background-position: center">
			<svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
				<rect width="100%" height="100%" fill="var(--bs-secondary-color)" />
			</svg>
			<div class="container">
				<div class="carousel-caption">
					<h1>Aquí cuidaremos de tus mascotas.</h1>
					<p>No importa que animal sea, lo cuidaremos y le daremos cariño para que se sienta seguro en el momento que lo requiera.</p>
					<p><a class="btn btn-lg btn-primary" href="#">Más información</a></p>
				</div>
			</div>
		</div>
		<div class="carousel-item" style="background-image: url(../img/galeria.jpg); background-repeat: no-repeat; background-size: cover; background-position: center">
			<svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
				<rect width="100%" height="100%" fill="var(--bs-secondary-color)" />
			</svg>
			<div class="container">
				<div class="carousel-caption text-end">
					<h1>Revisa nuestra galeria.</h1>
					<p>Encontrarás todo tipo de animales, los cuidamos, limpiamos, paseamos y muchas cosas más, mira aquí algunas fotos.</p>
					<p><a class="btn btn-lg btn-primary" href="#">Mirar galería</a></p>
				</div>
			</div>
		</div>
	</div>
	<button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Previous</span>
	</button>
	<button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Next</span>
	</button>
</div>

<!-- Marketing messaging and featurettes
  ================================================== -->
<!-- Wrap the rest of the page in another container to center all the content. -->

<div class="container marketing">
	<!-- Three columns of text below the carousel -->
	<div class="row">
		<div class="col-lg-4">
			<div class="rounded-circle mx-auto" style="height: 192px; width: 192px; background-image: url(../img/platform.jpg); background-repeat: no-repeat; background-size: cover; background-position: center"></div>
			<h2 class="fw-normal">Plataformas</h2>
			<p>Mira algunas de nuestras plataformas, donde tambien puedes brindarle protección a tu compañero y asegurarte incluso a ti mismo.</p>
			<p><a class="btn btn-secondary" href="./platform.php">Ver detalles &raquo;</a></p>
		</div>
		<!-- /.col-lg-4 -->
		<div class="col-lg-4">
			<div class="rounded-circle mx-auto" style="height: 192px; width: 192px; background-image: url(../img/contact.jpg); background-repeat: no-repeat; background-size: cover; background-position: center"></div>
			<h2 class="fw-normal">Contáctanos</h2>
			<p>Te respondemos preguntas e inquietudes ya sea sobre la plataforma, como registrar a tu animal y todo lo que nos quieras contar.</p>
			<p><a class="btn btn-secondary" href="./contact.php">Ver detalles &raquo;</a></p>
		</div>
		<!-- /.col-lg-4 -->
		<div class="col-lg-4">
			<div class="rounded-circle mx-auto" style="height: 192px; width: 192px; background-image: url(../img/recomendactions.jpg); background-repeat: no-repeat; background-size: cover; background-position: center"></div>
			<h2 class="fw-normal">Danos recomendaciones</h2>
			<p>Ayudanos a mejorar, cuentanos tu experiencia dentro de nuestra página y dinos que recomendaciones harías para ser mejor por todos.</p>
			<p><a class="btn btn-secondary" href="./recommendations.php">Ver detalles &raquo;</a></p>
		</div>
		<!-- /.col-lg-4 -->
	</div>
	<!-- /.row -->



	<!-- /END THE FEATURETTES -->
</div>
<div id="form" class="container">
	<!-- START THE FEATURETTES -->

	<hr class="featurette-divider" />
	<h2>Hospital-Formulario-Mascota</h2>
	<h5>A continuación podrás registrar tu mascota, es obligatorio que respondas cada uno de los datos solicitados para poder unirlos a la familia.</h5>
	<br />
	<form method="post" action="#">
		<h6>Digite el nombre del animal:</h6>
		<input class="form-control" type="text" name="nombre del animal" placeholder="Digite el nombre del animal" />
		<br /><br />
		<h6>Digite el nombre de la persona:</h6>
		<input class="form-control" type="text" name="nombre de la persona" placeholder="Digite el nombre de la persona" />
		<br /><br />
		<h6>Indique cual es la edad del animal:</h6>
		<input class="form-control" type="number" name="edad del animal" placeholder="Indique la edad en numeros" />
		<br /><br />
		<h6>Seleccione el tipo de animal:</h6>
		<select class="form-control" name="raza">
			<option value="1">Seleccionar</option>
			<option value="2">Perro</option>
			<option value="3">Gato</option>
			<option value="4">Conejo</option>
			<option value="5">Hamster</option>
			<option value="6">Ave</option>
		</select>
		<br /><br />
		<h6>Seleccione el color del animal:</h6>
		<input type="color" name="color de mascota" />
		<br /><br />
		<h6>Explique el motivo de traer al animal:</h6>
		<input class="form-control" type="text" name="motivo de llegada" placeholder="Explique..." />
		<br /><br />
		<input class="form-control" type="submit" value="Registrar" />
	</form>
	<hr class="featurette-divider" />
</div>
<!-- /.container -->
<?php
require_once "./_footer.php";
?>