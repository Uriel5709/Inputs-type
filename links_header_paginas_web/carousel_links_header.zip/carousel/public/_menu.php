<ul class="navbar-nav me-auto mb-2 mb-md-0">
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Inicio</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./platform.php">Plataformas</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./contact.php">Contáctanos</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./recommendations.php">Recomiendaciones</a>
    </li>
  
</ul>