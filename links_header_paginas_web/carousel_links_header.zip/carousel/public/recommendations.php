<?php
require_once "./_header.php";
?>

<div id="myCarousel" class="carousel slide mb-6" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner" style="background-image: url(../img/registro.jpg); background-repeat: no-repeat; background-size: cover; background-position: center">
        <div class="carousel-item">
            <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
                <rect width="100%" height="100%" fill="var(--bs-secondary-color)" />
            </svg>
            <div class="container">
                <div class="carousel-caption text-start">
                    <h1>Empieza desde ya!</h1>
                    <p class="opacity-75">Registra tu mascota en nuestro hospital, y dale un seguro de vida a tu amigo fiel.</p>
                    <p><a class="btn btn-lg btn-primary" href="index.php">Registrar aquí</a></p>
                </div>
            </div>
        </div>
        <div class="carousel-item active" style="background-image: url(../img/cuidamosmascota.jpg); background-repeat: no-repeat; background-size: cover; background-position: center">
            <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
                <rect width="100%" height="100%" fill="var(--bs-secondary-color)" />
            </svg>
            <div class="container">
                <div class="carousel-caption">
                    <h1>Aquí cuidaremos de tus mascotas.</h1>
                    <p>No importa que animal sea, lo cuidaremos y le daremos cariño para que se sienta seguro en el momento que lo requiera.</p>
                    <p><a class="btn btn-lg btn-primary" href="#">Más información</a></p>
                </div>
            </div>
        </div>
        <div class="carousel-item" style="background-image: url(../img/galeria.jpg); background-repeat: no-repeat; background-size: cover; background-position: center">
            <svg class="bd-placeholder-img" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
                <rect width="100%" height="100%" fill="var(--bs-secondary-color)" />
            </svg>
            <div class="container">
                <div class="carousel-caption text-end">
                    <h1>Revisa nuestra galeria.</h1>
                    <p>Encontrarás todo tipo de animales, los cuidamos, limpiamos, paseamos y muchas cosas más, mira aquí algunas fotos.</p>
                    <p><a class="btn btn-lg btn-primary" href="#">Mirar galería</a></p>
                </div>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<div class="container text-center">
    <ul>

        <h1>¡Recomendaciones!</h1>
        <br>
        Danos tus recomendaciones, dinos porque deberiamos mejorar y ayudanos a ser mejor por todos y para todos.
        <br>
        Escribe que te parecio la experiencia y dinos que arreglar.
    </ul>

    <form>
        <input type="text" class="form-control" placeholder="Escribe aquí..." >
        <br>
        <button type="submit" class="btn btn-primary" style="width: 500px;">Enviar</button>
    </form>
</div>

<?php
require_once "./_footer.php";
?>