<?php
    header('Location: ./public/index.php');
?>