<header class="bd-header bg-dark py-3 d-flex align-items-stretch border-bottom border-dark">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <h1 class="d-flex align-items-center fs-4 text-white mb-0">
            <img src="../../assets/brand/bootstrap-logo-white.svg" width="38" height="30" class="me-3" alt="Bootstrap" />
            BuscaTrabajo.com
        </h1>
        <nav class="nav nav-masthead justify-content-center flex-grow-1">
            <a class="nav-link text-white" href="_caracteristicas.php">Características</a>
            <a class="nav-link text-white" href="_detalles_t.php">Detalles Técnicos</a>
            <a class="nav-link text-white" href="_soporte_t.php">Soporte Técnico</a>
            <a class="nav-link text-white" href="_ayuda.php">Ayúda</a>
        </nav>
        <a href="index.php" class="ms-auto link-light">BuscaTrabajo.com</a>
    </div>
</header>