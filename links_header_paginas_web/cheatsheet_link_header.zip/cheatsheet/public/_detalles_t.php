<!DOCTYPE html>
<html lang="es" data-bs-theme="auto">

<head>
	<script src="../../assets/js/color-modes.js"></script>

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="description" content="" />
	<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
	<meta name="generator" content="Hugo 0.122.0" />
	<title>BuscaTrabajo</title>

	<link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/cheatsheet/" />

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3" />

	<link href="../../assets/dist/css/bootstrap.min.css" rel="stylesheet" />

	<style>
		.bd-placeholder-img {
			font-size: 1.125rem;
			text-anchor: middle;
			-webkit-user-select: none;
			-moz-user-select: none;
			user-select: none;
		}

		@media (min-width: 768px) {
			.bd-placeholder-img-lg {
				font-size: 3.5rem;
			}
		}

		.b-example-divider {
			width: 100%;
			height: 3rem;
			background-color: rgba(0, 0, 0, 0.1);
			border: solid rgba(0, 0, 0, 0.15);
			border-width: 1px 0;
			box-shadow: inset 0 0.5em 1.5em rgba(0, 0, 0, 0.1), inset 0 0.125em 0.5em rgba(0, 0, 0, 0.15);
		}

		.b-example-vr {
			flex-shrink: 0;
			width: 1.5rem;
			height: 100vh;
		}

		.bi {
			vertical-align: -0.125em;
			fill: currentColor;
		}

		.nav-scroller {
			position: relative;
			z-index: 2;
			height: 2.75rem;
			overflow-y: hidden;
		}

		.nav-scroller .nav {
			display: flex;
			flex-wrap: nowrap;
			padding-bottom: 1rem;
			margin-top: -1px;
			overflow-x: auto;
			text-align: center;
			white-space: nowrap;
			-webkit-overflow-scrolling: touch;
		}

		.btn-bd-primary {
			--bd-violet-bg: #2cf9;
			--bd-violet-rgb: 112.520718, 44.062154, 249.437846;

			--bs-btn-font-weight: 600;
			--bs-btn-color: var(--bs-white);
			--bs-btn-bg: var(--bd-violet-bg);
			--bs-btn-border-color: var(--bd-violet-bg);
			--bs-btn-hover-color: var(--bs-white);
			--bs-btn-hover-bg: #8e0;
			--bs-btn-hover-border-color: #fd3;
			--bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
			--bs-btn-active-color: var(--bs-btn-hover-color);
			--bs-btn-active-bg: #123;
			--bs-btn-active-border-color: #fd3;
		}

		.bd-mode-toggle {
			z-index: 1500;
		}

		.bd-mode-toggle .dropdown-menu .active .bi {
			display: block !important;
		}
	</style>

	<!-- Custom styles for this template -->
	<link href="../css/cheatsheet.css" rel="stylesheet" />
</head>

<body class="bg-body-tertiary">

	<?php
	require_once "_menu.php";
	?>

	<svg xmlns="http://www.w3.org/2000/svg" class="d-none">
		<symbol id="check2" viewBox="0 0 16 16">
			<path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
		</symbol>
		<symbol id="circle-half" viewBox="0 0 16 16">
			<path d="M8 15A7 7 0 1 0 8 1v14zm0 1A8 8 0 1 1 8 0a8 8 0 0 1 0 16z" />
		</symbol>
		<symbol id="moon-stars-fill" viewBox="0 0 16 16">
			<path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z" />
			<path
				d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.734 1.734 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.734 1.734 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.734 1.734 0 0 0 1.097-1.097l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732L13.863.1z" />
		</symbol>
		<symbol id="sun-fill" viewBox="0 0 16 16">
			<path
				d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z" />
		</symbol>
	</svg>

	<div class="dropdown position-fixed bottom-0 end-0 mb-3 me-3 bd-mode-toggle">
		<button class="btn btn-bd-primary py-2 dropdown-toggle d-flex align-items-center" id="bd-theme" type="button" aria-expanded="false" data-bs-toggle="dropdown" aria-label="Toggle theme (auto)">
			<svg class="bi my-1 theme-icon-active" width="1em" height="1em">
				<use href="#circle-half"></use>
			</svg>
			<span class="visually-hidden" id="bd-theme-text">Toggle theme</span>
		</button>
		<ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="bd-theme-text">
			<li>
				<button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="light" aria-pressed="false">
					<svg class="bi me-2 opacity-50" width="1em" height="1em">
						<use href="#sun-fill"></use>
					</svg>
					Claro
					<svg class="bi ms-auto d-none" width="1em" height="1em">
						<use href="#check2"></use>
					</svg>
				</button>
			</li>
			<li>
				<button type="button" class="dropdown-item d-flex align-items-center" data-bs-theme-value="dark" aria-pressed="false">
					<svg class="bi me-2 opacity-50" width="1em" height="1em">
						<use href="#moon-stars-fill"></use>
					</svg>
					Oscuro
					<svg class="bi ms-auto d-none" width="1em" height="1em">
						<use href="#check2"></use>
					</svg>
				</button>
			</li>
			<li>
				<button type="button" class="dropdown-item d-flex align-items-center active" data-bs-theme-value="auto" aria-pressed="true">
					<svg class="bi me-2 opacity-50" width="1em" height="1em">
						<use href="#circle-half"></use>
					</svg>
					Automático
					<svg class="bi ms-auto d-none" width="1em" height="1em">
						<use href="#check2"></use>
					</svg>
				</button>
			</li>
		</ul>
	</div>
	<aside class="bd-aside sticky-xl-top text-body-secondary align-self-start mb-3 mb-xl-5 px-2">
		<h2 class="h6 pt-4 pb-3 mb-4 border-bottom">En la página</h2>
		<nav class="small" id="toc">
			<ul class="list-unstyled">
				<li class="my-2">
					<button type="button" class="btn d-inline-flex align-items-center collapsed border-0" data-bs-toggle="collapse" aria-expanded="false" data-bs-target="#contents-collapse" aria-controls="contents-collapse">Contenido</button>
					<ul class="list-unstyled ps-3 collapse" id="contents-collapse">
						<li><a class="d-inline-flex align-items-center rounded text-decoration-none" href="#bienvenido">Detalles Técnicos</a></li>
					</ul>
				</li>
				<li class="my-2">
					<button type="button" class="btn d-inline-flex align-items-center collapsed border-0" data-bs-toggle="collapse" aria-expanded="false" data-bs-target="#components-collapse" aria-controls="components-collapse">Contáctanos</button>
					<ul class="list-unstyled ps-3 collapse" id="components-collapse">
						<li><a class="d-inline-flex align-items-center rounded text-decoration-none" href="#informacion">Información</a></li>
						<li><a class="d-inline-flex align-items-center rounded text-decoration-none" href="#informacion">Redes sociales</a></li>
						<li><a class="d-inline-flex align-items-center rounded text-decoration-none" href="#informacion">Números telefónicos</a></li>
					</ul>
				</li>
			</ul>
		</nav>
	</aside>
	<div class="bd-cheatsheet container-fluid bg-body">
		<section id="content">
			<h2 class="sticky-xl-top fw-bold pt-3 pt-xl-5 pb-2 pb-xl-3">Contenido</h2>

			<article class="my-3" id="bienvenido">
				<div class="bd-heading sticky-xl-top align-self-start mt-5 mb-3 mt-xl-0 mb-xl-2">
					<h3>Detalles Técnicos</h3>
					<a class="d-flex align-items-center" href="../content/bienvenido/">información</a>
				</div>

				<div>


					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<p class="h1"><mark><strong>Mira nuestros detalles</strong></mark></p>
						</div>
					</div>

					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<p class="lead">Te mostramos detalles para que no dudes en nuestro proceso como empresa.</p>
						</div>
					</div>

					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<p>Unidos somos lo mejor, que ustedes nos ayuden explorando es mejor,</p>
							<p>no solo estamos aquí para que busques un trabajo, sino que tambien</p>
							<p>para darte oportunidades a salir adelante, incluso trabajando con</p>
							<p>nosotros mismos, esta empresa tiene los permisos de cada página a</p>
							<p>la que te lleva cada que haces click.</p>
						</div>
					</div>

					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<hr />
						</div>
					</div>

					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<blockquote class="blockquote">
								<p>Tenemos redes y direcciones confiables.</p>
								<footer class="blockquote-footer">Cada una autorizada con sus permisos</footer>
							</blockquote>
						</div>
					</div>

					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<ul class="list-unstyled">
								<li>Verifica siempre que estas llegando a los lugares correctos,</li>
								<li>si tienes algún problema pues dirigirte a nuestro apartado de</li>
								<li><a class="text-white" href="_soporte_t.php">Soporte Técnico</a> donde te ayudaremos a resolverlo de forma</li>
								<li>rapida e instantanea.</li>
								<br>
								<li>
								Recuerda, tenemos:
									<ul>
										<li>Cursos</li>
										<li>Soporte 24/7</li>
										<li>Páginas diversas que puedes explorar</li>
									</ul>
								</li>
								<br>
								<li>Sientete comodo y has parte de la comunidad.</li>
							</ul>
						</div>
					</div>


				</div>
			</article>
			
		</section>

		<section id="forms">
			<article class="my-3" id="breadcrumb">
				<div class="bd-heading sticky-xl-top align-self-start mt-5 mb-3 mt-xl-0 mb-xl-2"></div>

				<div>
					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<nav aria-label="breadcrumb">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="#bienvenido">Hogar</a></li>
									<li class="breadcrumb-item"><a href="#bienvenido">Librería</a></li>
									<li class="breadcrumb-item active" aria-current="page">Datos</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
			</article>

			<br><br><br><br>
			<article class="my-3" id="informacion">
				<div class="bd-heading sticky-xl-top align-self-start mt-5 mb-3 mt-xl-0 mb-xl-2">
					<h3>Información</h3>
					<a class="d-flex align-items-center" href="../components/carousel/">Documentación</a>
				</div>

				<div>
					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0">
							<div class="row row-cols-1 row-cols-md-2 g-4">
								<div class="col">
									<div class="card">
										<div class="card-img-top" style="background-image: url('../img/programador.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center; height: 180px;">
										</div>
										<div class="card-body">
											<h5 class="card-title">Programadores</h5>
											<p class="card-text">En esta app podrás comunicarte con demas programadores e ingenieros en sistemas, y ofertar tu experiencia como ingeniero.</p>
											<a href="#" class="btn btn-primary">Ir a la página</a>
										</div>
									</div>
								</div>
								<div class="col">
									<div class="card">
										<div class="card-header">Presentación</div>
										<div class="card-body">
											<h5 class="card-title">Agricultores</h5>
											<p class="card-text">Ayuda a producir el alimento y pan de cada día, ustedes son la principal razón por la que disponemos de alimentos saludables.</p>
											<a href="#" class="btn btn-primary">Ir a la página</a>
										</div>
										<div class="card-footer text-body-secondary">Hace 2 días</div>
									</div>
								</div>
								<div class="col">
									<div class="card">
										<div class="card-body">
											<h5 class="card-title">Abogados</h5>
											<p class="card-text">¿Ya eres abogado?, comunicate y busca personas a las que puedas ayudar en sus casos legales, haste reconocer y ayuda a los demás.</p>
										</div>
										<ul class="list-group list-group-flush">
											<li class="list-group-item">Casos</li>
											<li class="list-group-item">Investigaciones</li>
											<li class="list-group-item">Procesos</li>
										</ul>
										<div class="card-body">
											<a href="#" class="card-link">link abogados</a>
											<a href="#" class="card-link">abogados.com</a>
										</div>
									</div>
								</div>
								<div class="col">
									<div class="card">
										<div class="row g-0">
											<div class="col-md-4">
												<div class="card-img-top" style="background-image: url('../img/periodistas.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center; height: 200px;">
												</div>
											</div>
											<div class="col-md-8">
												<div class="card-body">
													<h5 class="card-title">Periodistas</h5>
													<p class="card-text">Si tienes habilidades para la comunicación, estas en el lugar correcto, en este lugar encontrarás oportunidades para expandir tu carrera como telecomunicador.</p>
													<p class="card-text"><small class="text-body-secondary">Última actualización hace 3 días</small></p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<br><br><br><br><br><br>
							<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
								<div class="carousel-indicators">
									<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
									<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
									<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
								</div>
								<div class="carousel-inner">
									<div class="carousel-item active" style="background-image: url('../img/curso.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center;">
										<svg class="bd-placeholder-img bd-placeholder-img-lg d-block w-100" width="800" height="400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: First slide" preserveAspectRatio="xMidYMid slice" focusable="false" style="opacity: 0;">
											<title>Cursos</title>
											<rect width="100%" height="100%" fill="#777" />
										</svg>
										<div class="carousel-caption d-none d-md-block">
											<h5>Cursos gratuitos!</h5>
											<p>Ven y unete a nosotros en nuestros cursos gratis de todo tipo de temas.</p>
										</div>
									</div>
									<div class="carousel-item" style="background-image: url('../img/plataforma.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center;">
										<svg class="bd-placeholder-img bd-placeholder-img-lg d-block w-100" width="800" height="400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Second slide" preserveAspectRatio="xMidYMid slice" focusable="false" style="opacity: 0;">
											<title>Plataformas</title>
											<rect width="100%" height="100%" fill="#666" />
										</svg>
										<div class="carousel-caption d-none d-md-block">
											<h5>Plataformas externas</h5>
											<p>Indaga más sobre nuestras plataformas, donde te ofrecemos demás servicios y cosas interesantes.</p>
										</div>
									</div>
									<div class="carousel-item" style="background-image: url('../img/contactanos.jpg'); background-repeat: no-repeat; background-size: cover; background-position: center;">
										<svg class="bd-placeholder-img bd-placeholder-img-lg d-block w-100" width="800" height="400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Third slide" preserveAspectRatio="xMidYMid slice" focusable="false" style="opacity: 0;">
											<title>Placeholder</title>
											<rect width="100%" height="100%" fill="#555" />
										</svg>
										<div class="carousel-caption d-none d-md-block">
											<h5>¿Quieres conocernos más?</h5>
											<p>Tambien disponemos de redes sociales, y números telefónicos donde puedes contactarnos. ¡Llama ya!</p>
										</div>
									</div>
								</div>
								<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
									<span class="carousel-control-prev-icon" aria-hidden="true"></span>
									<span class="visually-hidden">Previous</span>
								</button>
								<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
									<span class="carousel-control-next-icon" aria-hidden="true"></span>
									<span class="visually-hidden">Next</span>
								</button>
							</div>
						</div>
					</div>
				</div>
			</article>




			<article class="my-3" id="toasts">
				<div class="bd-heading sticky-xl-top align-self-start mt-5 mb-3 mt-xl-0 mb-xl-2"></div>

				<div>
					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0 bg-dark p-5 align-items-center">
							<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
								<div class="toast-header">
									<svg class="bd-placeholder-img rounded me-2" width="20" height="20" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice" focusable="false">
										<rect width="100%" height="100%" fill="#007aff" />
									</svg>
									<strong class="me-auto">Jefe de trabajo</strong>
									<small class="text-body-secondary">Hace 5 minutos</small>
									<button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
								</div>
								<div class="toast-body">Hola, quieres aprender más sobre como triunfar en la vida?</div>
							</div>
						</div>
					</div>
				</div>
			</article>
			<article class="mt-3 mb-5 pb-5" id="tooltips">
				<div class="bd-heading sticky-xl-top align-self-start mt-5 mb-3 mt-xl-0 mb-xl-2"></div>

				<div>
					<div class="bd-example-snippet bd-code-snippet">
						<div class="bd-example m-0 border-0 tooltip-demo">
							<button type="button" class="btn btn-secondary" data-bs-toggle="tooltip" data-bs-placement="top" title="Haz click aquí">Información sobre nosotros</button>
							<button type="button" class="btn btn-secondary" data-bs-toggle="tooltip" data-bs-placement="right" title="Haz click aquí">Contáctanos aquí</button>
							<button type="button" class="btn btn-secondary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Haz click aquí">Encuentra nuestras páginas web...</button>
							<button type="button" class="btn btn-secondary" data-bs-toggle="tooltip" data-bs-placement="left" title="Haz click aquí">Quieres trabajar con nosotros?, ven ya!</button>
							<button type="button" class="btn btn-secondary" data-bs-toggle="tooltip" data-bs-html="true" title="Haz click aquí">Especializate en lo que sabes hacer y eres bueno</button>
						</div>
					</div>
				</div>
			</article>
		</section>
	</div>




	<div class="modal fade" id="exampleModalFullscreen" tabindex="-1" aria-labelledby="exampleModalFullscreenLabel" aria-hidden="true">
		<div class="modal-dialog modal-fullscreen">
			<div class="modal-content">
				<div class="modal-header">
					<h1 class="modal-title fs-4" id="exampleModalFullscreenLabel">Full screen modal</h1>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">...</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
	<script src="../../assets/dist/js/bootstrap.bundle.min.js"></script>

	<script src="../js/cheatsheet.js"></script>
</body>

</html>