<?php

$n1 = $_POST["n1"];
$n2 = $_POST["n2"];
$ecuacion = $_POST["ecuacion"];

if ($ecuacion == 1){
    $suma = $n1 + $n2;
    print("La suma es igual a: " .$suma);
}
if ($ecuacion == 2){
    $resta = $n1 - $n2;
    print("La resta es igual a: " .$resta);
}
if ($ecuacion == 3){
    $multi = $n1 * $n2;
    print("La multiplicacion es igual a: " .$multi);
}
if ($ecuacion == 4){
   if ($n1 > 0 && $n2 > 0) {
    $div = $n1 / $n2;
    if ($div > 0) {
        print("La division es igual a: " .$div);
    }
    else{
        print("Error.");
    }
   } 
   else{
    print("Error.");
} 
    
    
}
?>