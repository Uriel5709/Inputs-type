<?php

$nombre = $_POST["nombre"];
$descripcion = $_POST["descripcion"];
$valor = $_POST["valor"];

if ($valor > 0) {
    print "Nombre: ". $nombre. "<br>";
    print "Descripcion: ". $descripcion. "<br>";
    print "Valor total: ". $valor ." pesos";
}
else {
    print "El valor o algun dato digitado es incorrecto.";
}

?>