<?php

$nombre = $_POST["nombre"];
$edad = $_POST["edad"];
$doc = $_POST["doc"];

if ($edad >= 18) {
    print "Eres mayor de edad.<br>";
    print "Has sido registrado como:.<br>";
    print "Nombre: ". $nombre ."<br>";
    print "Edad: ". $edad ."<br>";
    print "Documento: ". $doc;
} 
else {
    print "No eres mayor de edad, no puedes registrarte.";
}

?>