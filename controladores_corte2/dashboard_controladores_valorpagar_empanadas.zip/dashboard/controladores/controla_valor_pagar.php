<?php

$edad = $_POST["edad"];
$valor = $_POST["valor_paga"];
$descuento = $valor * 0.20;
$valor_descuento = $valor - $descuento;

if ($edad >= 18) {
    print "Eres mayor de edad.<br>";
    if ($valor >= 1000) {
        if ($edad >= 60) {
            print "Se ha realizado el descuento debido a su edad, el valor total a pagar es de: " . ($valor_descuento);
        } else {
            print "El descuento no aplica, el valor total a pagar es de: " . ($valor);
        }
    } else {
        print "Pero...<br>" . "La cantidad ingresada en el valor es incorrecta, no puedes continuar.";
    }
} else {
    print "No eres mayor de edad, no puedes realizar el pago.";
}

?>