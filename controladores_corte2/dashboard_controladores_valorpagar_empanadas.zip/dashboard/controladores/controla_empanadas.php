<?php

$cantidad_empanadas = $_POST["numero_empanadas"];
$precio_unitario = 2000;
$total = $cantidad_empanadas * $precio_unitario;

if ($cantidad_empanadas <= 1) {
    print "La cantidad no es valida";
} else {
    print "El valor total de su compra es de: " . ($cantidad_empanadas * $precio_unitario) . "K";
}

?>