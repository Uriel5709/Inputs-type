<?php

    $cantidad_churros = $_POST["cantidad"];
    $precio_unitario = 1500;
    $total = $cantidad_churros*$precio_unitario;


    if ($cantidad_churros<=0) {
        print "no es valido";
    }
    else {
        print "El valor total por su compra es de: ".($cantidad_churros*$precio_unitario)."K";
     }
?>