<?php

$nombre_persona = $_POST["nombre"];
$documento = $_POST["doc"];
$fecha_nacimiento = $_POST["fecha"];
$celular = $_POST["telefono"];

print "<br>Su nombre es: ".$nombre_persona;
print "<br>El Documento es: ".$documento;
print "<br>La fecha de nacimiento es: ".$fecha_nacimiento;
print "<br>El numero telefonico es: ".$celular;

?>