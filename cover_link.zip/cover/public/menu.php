<header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0"><a class="nav-link fw-bold py-1 px-0 active" href="index.php">Inicio</a></h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="_caracteristicas.php">Características</a>
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="_detalles_t.php">Detalles Técnicos</a>
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="_soporte_t.php">Soporte Técnico</a>
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="_ayuda.php">Ayúda</a>
      </nav>
    </div>
  </header>